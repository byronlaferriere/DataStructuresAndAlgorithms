//============================================================================
// Name        : LinkedList.cpp
// Author      : Byron Laferriere
// Version     : 1.0
// Copyright   : Copyright © 2017 SNHU COCE
// Description : Lab 3-3 Lists and Searching
//============================================================================

#include <algorithm>
#include <iostream>
#include <time.h>

#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// forward declarations
double strToDouble(string str, char ch);

// define a structure to hold bid information
struct Bid {
    string bidId; // unique identifier
    string title;
    string fund;
    double amount;
    Bid() {
        amount = 0.0;
    }
};

//============================================================================
// Linked-List class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a linked-list.
 */
class LinkedList {

private:
    // FIXME (1): Internal structure for list entries, housekeeping variables
	//BEGIN PSEUDO:
	//First we create a structure called Node to store the list entries and variables that will be needed
	//throughout the program. We can then use a pointer from Node to next to begin our list modifications.
	struct Node {
		Bid bid;
		Node* next;


		// DEFAULT CONSTRUCTOR
		Node() {
			next = nullptr;
		}
		// INITIALIZE A NODE WITH A BID
		Node(Bid aBid) {
			bid = aBid;
			next = nullptr;
		}
	};

	Node* head;
	Node* tail;
	int size = 0;
public:
    LinkedList();
    virtual ~LinkedList();
    void Append(Bid bid);
    void Prepend(Bid bid);
    void PrintList();
    void Remove(string bidId);
    Bid Search(string bidId);
    int Size();
};

/**
 * Default constructor
 */
LinkedList::LinkedList() {
    // FIXME (2): Initialize housekeeping variables
	// initializing our head and tail == null
	// we can this either combined, like below, or in two separate variable definitions
	// assigning values to null allows for the node to be updated when selected easily
	head = tail = nullptr;
}

/**
 * Destructor
 */
LinkedList::~LinkedList() {
}

/**
 * Append a new bid to the end of the list
 */
void LinkedList::Append(Bid bid) {
    // FIXME (3): Implement append logic
	// Using a pointer again, we tell the program what to do with the input
	// Node is pointing to a new node, and this new node is going to store the bid
	// using a if loop, we can control what happens if the head node is null
	// finishing our if loop with an else loop, we tell the program if the tail does not == null
	// to then create a new node behind it in the list
	Node* node = new Node(bid);

	if (head == nullptr) {
		head = node;

	}
	else {
		if ( tail != nullptr) {
			tail->next = node;
		}
	}

	//NEW NODE ALWAYS ASSIGNS TO TAIL
	tail = node;
	size ++;
}
/**
 * Prepend a new bid to the start of the list
 */
void LinkedList::Prepend(Bid bid) {
    // FIXME (4): Implement prepend logic
	//similar to append, prepend is going to have a similar setup for list ediiting
	//prepend will be set up to add before instead of anywhere in the list

	Node* node = new Node(bid);
	if (head != nullptr) {
		node->next = head;
	}
	head = node;
	size++;
}

/**
 * Simple output of all bids in the list
 */
void LinkedList::PrintList() {
    // FIXME (5): Implement print logic
	// we want to display variables present in data, upon request, so we will need to set up a while loop that checks for current
	//node to != nullptr. By setting it up this way, we tell the program to display bid info while current holds a real value
	Node* current = head;

	//looping over each node looking for a match
	while (current != nullptr) {
		cout << current->bid.bidId << ": " << current->bid.title << " | "
				<< current->bid.amount << " | " << current->bid.fund << endl;
		current = current->next;
	}
}

/**
 * Remove a specified bid
 *
 * @param bidId The bid id to remove from the list
 */
void LinkedList::Remove(string bidId) {
    // FIXME (6): Implement remove logic
	// first, we need to set up an if loop to check that the head node is not null
	// we can use the .compare() function to check for a zero value being stored in the head of the list
	// if this evaluates to true, the program will delete the head and reassign head and tail
	if (head != nullptr) {
		if (head->bid.bidId.compare(bidId)== 0) {
			delete head;
			head = nullptr;
			tail = nullptr;
		}
	}
	Node* current = head;
		//looping over each node looking for a match
		while (current->next != nullptr) {
			if (current->next->bid.bidId.compare(bidId) == 0){
				//save the next node (node being removed)
				Node* tempNode = current->next;

				//make current node point to the next one (beyond) to be removed
				current->next = tempNode->next;
				//now we can delete temp node stored
				delete tempNode;

				size--;

				return;
			}
			current = current->next;
		}
}

/**
 * Search for the specified bidId
 *
 * @param bidId The bid id to search for
 */
Bid LinkedList::Search(string bidId) {
    // FIXME (7): Implement search logic
	//start by using a pointer from  node to current, which assigns this as head now
	//we need to set this up to look for a node and return the value of this node.
	Node* current = head;
	//looping over each node looking for a match
	//implementing a while loop to check for statement validity.
	while (current != nullptr) {
		if (current->bid.bidId.compare(bidId) == 0){
			return current->bid;
		}
		current = current->next;
	}
}
//END PSEUDO:

/**
 * Returns the current size (number of elements) in the list
 */
int LinkedList::Size() {
    return size;
}

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the bid information
 *
 * @param bid struct containing the bid info
 */
void displayBid(Bid bid) {
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount
         << " | " << bid.fund << endl;
    return;
}

/**
 * Prompt user for bid information
 *
 * @return Bid struct containing the bid info
 */
Bid getBid() {
    Bid bid;

    cout << "Enter Id: ";
    cin.ignore();
    getline(cin, bid.bidId);

    cout << "Enter title: ";
    getline(cin, bid.title);

    cout << "Enter fund: ";
    cin >> bid.fund;

    cout << "Enter amount: ";
    cin.ignore();
    string strAmount;
    getline(cin, strAmount);
    bid.amount = strToDouble(strAmount, '$');

    return bid;
}

/**
 * Load a CSV file containing bids into a LinkedList
 *
 * @return a LinkedList containing all the bids read
 */
void loadBids(string csvPath, LinkedList *list) {
    cout << "Loading CSV file " << csvPath << endl;

    // initialize the CSV Parser
    csv::Parser file = csv::Parser(csvPath);

    try {
        // loop to read rows of a CSV file
        for (int i = 0; i < file.rowCount(); i++) {

            // initialize a bid using data from current row (i)
            Bid bid;
            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            //cout << bid.bidId << ": " << bid.title << " | " << bid.fund << " | " << bid.amount << endl;

            // add this bid to the end
            list->Append(bid);
        }
    } catch (csv::Error &e) {
        std::cerr << e.what() << std::endl;
    }
}

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

/**
 * The one and only main() method
 *
 * @param arg[1] path to CSV file to load from (optional)
 * @param arg[2] the bid Id to use when searching the list (optional)
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath, bidKey;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        bidKey = "98109";
        break;
    case 3:
        csvPath = argv[1];
        bidKey = argv[2];
        break;
    default:
        csvPath = "eBid_Monthly_Sales_Dec_2016.csv";
        bidKey = "98109";
    }

    clock_t ticks;

    LinkedList bidList;

    Bid bid;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Enter a Bid" << endl;
        cout << "  2. Load Bids" << endl;
        cout << "  3. Display All Bids" << endl;
        cout << "  4. Find Bid" << endl;
        cout << "  5. Remove Bid" << endl;
        cout << "  6. Prepend a Bid" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            bid = getBid();
            bidList.Append(bid);
            displayBid(bid);

            break;

        case 2:
            ticks = clock();

            loadBids(csvPath, &bidList);

            cout << bidList.Size() << " bids read" << endl;

            ticks = clock() - ticks; // current clock ticks minus starting clock ticks
            cout << "time: " << ticks << " milliseconds" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

            break;

        case 3:
            bidList.PrintList();

            break;

        case 4:
            ticks = clock();

            bid = bidList.Search(bidKey);

            ticks = clock() - ticks; // current clock ticks minus starting clock ticks

            if (!bid.bidId.empty()) {
                displayBid(bid);
            } else {
            	cout << "Bid Id " << bidKey << " not found." << endl;
            }

            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

            break;

        case 5:
            bidList.Remove(bidKey);

            break;

        case 6:
            bid = getBid();
            bidList.Prepend(bid);
            displayBid(bid);

            break;
        }
    }

    cout << "Good bye." << endl;

    return 0;
}

